import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { Router } from '@angular/router';
import { AuthService } from '../auth.service'; // Importa el servicio de autenticación

@Component({
  standalone: true,
  imports: [CommonModule, FormsModule],
  selector: 'app-chatbot',
  templateUrl: './chatbot.component.html',
  styleUrls: ['./chatbot.component.css'],
})
export class ChatbotComponent implements OnInit {
  messages: string[] = []; // Mensajes del chatbot
  userMessage: string = ''; // Mensaje ingresado por el usuario
  userEmail: string | null = null; // Correo del usuario autenticado

  constructor(private authService: AuthService, private router: Router) {}

  ngOnInit() {
    // Verificar si el usuario está autenticado
    if (!this.authService.isAuthenticated()) {

      this.router.navigate(['/login']); // Redirigir al login si no está autenticado
    } else {
      this.userEmail = this.authService.getEmail(); // Obtener el correo del usuario
    }
  }

  sendMessage() {
    if (this.userMessage.trim()) {
      this.messages.push(`Tú: ${this.userMessage}`);
      // Simular una respuesta del bot (puedes conectar un backend aquí)
      this.messages.push(`Bot: Respuesta a "${this.userMessage}"`);
      this.userMessage = ''; // Limpiar el campo de entrada
    }
  }

  logout() {
    this.authService.logout(); // Cerrar sesión
    this.router.navigate(['/login']); // Redirigir al login
  }
}
